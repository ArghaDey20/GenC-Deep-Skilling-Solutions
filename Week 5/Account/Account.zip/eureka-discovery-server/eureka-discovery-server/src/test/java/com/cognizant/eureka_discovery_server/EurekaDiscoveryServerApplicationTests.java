package com.cognizant.eureka_discovery_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
